﻿namespace Test
{
    partial class FormTest
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.zGraphTest = new Pengpai.UI.ZGraph();
            this.groupBox数据显示模拟 = new System.Windows.Forms.GroupBox();
            this.button数据显示模拟6 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox附加参数 = new System.Windows.Forms.TextBox();
            this.textBox数值 = new System.Windows.Forms.TextBox();
            this.button数据显示模拟7 = new System.Windows.Forms.Button();
            this.button数据显示模拟5 = new System.Windows.Forms.Button();
            this.button数据显示模拟4 = new System.Windows.Forms.Button();
            this.button数据显示模拟3 = new System.Windows.Forms.Button();
            this.button数据显示模拟2 = new System.Windows.Forms.Button();
            this.button数据显示模拟1 = new System.Windows.Forms.Button();
            this.groupBox基本属性 = new System.Windows.Forms.GroupBox();
            this.buttonY轴名称 = new System.Windows.Forms.Button();
            this.buttonX轴名称 = new System.Windows.Forms.Button();
            this.button标题 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxY轴名称 = new System.Windows.Forms.TextBox();
            this.textBoxX轴名称 = new System.Windows.Forms.TextBox();
            this.textBox标题 = new System.Windows.Forms.TextBox();
            this.button参考样式2 = new System.Windows.Forms.Button();
            this.groupBox外观样式 = new System.Windows.Forms.GroupBox();
            this.button网络线的透明度 = new System.Windows.Forms.Button();
            this.button标题位置 = new System.Windows.Forms.Button();
            this.button标题字体大小 = new System.Windows.Forms.Button();
            this.textBox网络线的透明度 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.button坐标显示框字体颜色 = new System.Windows.Forms.Button();
            this.button坐标显示框背景颜色 = new System.Windows.Forms.Button();
            this.button标签说明框背景颜色 = new System.Windows.Forms.Button();
            this.button标签说明框文字颜色 = new System.Windows.Forms.Button();
            this.button工具栏按钮前景未选中颜色 = new System.Windows.Forms.Button();
            this.button工具栏按钮前景选中颜色 = new System.Windows.Forms.Button();
            this.textBox标题字体大小 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button波形显示区域背景色 = new System.Windows.Forms.Button();
            this.button工具栏按钮背景色 = new System.Windows.Forms.Button();
            this.button工具栏背景色 = new System.Windows.Forms.Button();
            this.button网络线的颜色 = new System.Windows.Forms.Button();
            this.button坐标标题颜色 = new System.Windows.Forms.Button();
            this.button坐标值颜色 = new System.Windows.Forms.Button();
            this.button坐标线颜色 = new System.Windows.Forms.Button();
            this.button背景色渐进起始颜色 = new System.Windows.Forms.Button();
            this.button背景色渐进终止颜色 = new System.Windows.Forms.Button();
            this.button标题描边颜色 = new System.Windows.Forms.Button();
            this.button标题颜色 = new System.Windows.Forms.Button();
            this.textBox标题位置 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button默认样式 = new System.Windows.Forms.Button();
            this.button参考样式1 = new System.Windows.Forms.Button();
            this.timerDraw = new System.Windows.Forms.Timer(this.components);
            this.timerRandom = new System.Windows.Forms.Timer(this.components);
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox数据显示模拟.SuspendLayout();
            this.groupBox基本属性.SuspendLayout();
            this.groupBox外观样式.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.button参考样式2);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox外观样式);
            this.splitContainer1.Panel2.Controls.Add(this.button默认样式);
            this.splitContainer1.Panel2.Controls.Add(this.button参考样式1);
            this.splitContainer1.Panel2.Padding = new System.Windows.Forms.Padding(5);
            this.splitContainer1.Size = new System.Drawing.Size(792, 573);
            this.splitContainer1.SplitterDistance = 578;
            this.splitContainer1.TabIndex = 1;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.zGraphTest);
            this.splitContainer2.Panel1.Padding = new System.Windows.Forms.Padding(10);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.groupBox数据显示模拟);
            this.splitContainer2.Panel2.Controls.Add(this.groupBox基本属性);
            this.splitContainer2.Size = new System.Drawing.Size(578, 573);
            this.splitContainer2.SplitterDistance = 426;
            this.splitContainer2.TabIndex = 0;
            // 
            // zGraphTest
            // 
            this.zGraphTest.AllowDrop = true;
            this.zGraphTest.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.zGraphTest.BackColor = System.Drawing.Color.White;
            this.zGraphTest.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.zGraphTest.Location = new System.Drawing.Point(10, 10);
            this.zGraphTest.m_backColorH = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.zGraphTest.m_backColorL = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.zGraphTest.m_BigXYBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.zGraphTest.m_ControlButtonBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.zGraphTest.m_ControlButtonForeColorH = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.zGraphTest.m_ControlButtonForeColorL = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.zGraphTest.m_ControlItemBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.zGraphTest.m_coordinateLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.zGraphTest.m_coordinateStringColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.zGraphTest.m_coordinateStringTitleColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.zGraphTest.m_DirectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.zGraphTest.m_DirectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.zGraphTest.m_fXBeginSYS = 0F;
            this.zGraphTest.m_fXEndSYS = 60F;
            this.zGraphTest.m_fYBeginSYS = 0F;
            this.zGraphTest.m_fYEndSYS = 1F;
            this.zGraphTest.m_GraphBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.zGraphTest.m_iLineShowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.zGraphTest.m_iLineShowColorAlpha = 100;
            this.zGraphTest.m_ShowNumBackColor = System.Drawing.Color.White;
            this.zGraphTest.m_ShowNumForeClor = System.Drawing.Color.Black;
            this.zGraphTest.m_SySnameX = "X轴坐标";
            this.zGraphTest.m_SySnameY = "Y轴坐标";
            this.zGraphTest.m_SyStitle = "波形显示";
            this.zGraphTest.m_titleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.zGraphTest.m_titleColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.zGraphTest.m_titlePosition = 0.4F;
            this.zGraphTest.m_titleSize = 14;
            this.zGraphTest.Margin = new System.Windows.Forms.Padding(0);
            this.zGraphTest.MinimumSize = new System.Drawing.Size(390, 270);
            this.zGraphTest.Name = "zGraphTest";
            this.zGraphTest.Size = new System.Drawing.Size(558, 406);
            this.zGraphTest.TabIndex = 0;
            this.zGraphTest.DragEnter += new System.Windows.Forms.DragEventHandler(this.zGraphTest_DragEnter);
            // 
            // groupBox数据显示模拟
            // 
            this.groupBox数据显示模拟.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox数据显示模拟.Controls.Add(this.button数据显示模拟6);
            this.groupBox数据显示模拟.Controls.Add(this.label5);
            this.groupBox数据显示模拟.Controls.Add(this.label4);
            this.groupBox数据显示模拟.Controls.Add(this.textBox附加参数);
            this.groupBox数据显示模拟.Controls.Add(this.textBox数值);
            this.groupBox数据显示模拟.Controls.Add(this.button数据显示模拟7);
            this.groupBox数据显示模拟.Controls.Add(this.button数据显示模拟5);
            this.groupBox数据显示模拟.Controls.Add(this.button数据显示模拟4);
            this.groupBox数据显示模拟.Controls.Add(this.button数据显示模拟3);
            this.groupBox数据显示模拟.Controls.Add(this.button数据显示模拟2);
            this.groupBox数据显示模拟.Controls.Add(this.button数据显示模拟1);
            this.groupBox数据显示模拟.ForeColor = System.Drawing.Color.Black;
            this.groupBox数据显示模拟.Location = new System.Drawing.Point(12, 3);
            this.groupBox数据显示模拟.Name = "groupBox数据显示模拟";
            this.groupBox数据显示模拟.Size = new System.Drawing.Size(335, 128);
            this.groupBox数据显示模拟.TabIndex = 1;
            this.groupBox数据显示模拟.TabStop = false;
            this.groupBox数据显示模拟.Text = "数据显示模拟";
            // 
            // button数据显示模拟6
            // 
            this.button数据显示模拟6.Location = new System.Drawing.Point(234, 99);
            this.button数据显示模拟6.Name = "button数据显示模拟6";
            this.button数据显示模拟6.Size = new System.Drawing.Size(95, 23);
            this.button数据显示模拟6.TabIndex = 10;
            this.button数据显示模拟6.Text = "停止采样显示";
            this.button数据显示模拟6.UseVisualStyleBackColor = true;
            this.button数据显示模拟6.Click += new System.EventHandler(this.button数据显示模拟6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(129, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 12);
            this.label5.TabIndex = 9;
            this.label5.Text = "分块存文件点数";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "测试数据值";
            // 
            // textBox附加参数
            // 
            this.textBox附加参数.Location = new System.Drawing.Point(221, 16);
            this.textBox附加参数.Name = "textBox附加参数";
            this.textBox附加参数.Size = new System.Drawing.Size(33, 21);
            this.textBox附加参数.TabIndex = 7;
            // 
            // textBox数值
            // 
            this.textBox数值.Location = new System.Drawing.Point(75, 14);
            this.textBox数值.Name = "textBox数值";
            this.textBox数值.Size = new System.Drawing.Size(48, 21);
            this.textBox数值.TabIndex = 6;
            // 
            // button数据显示模拟7
            // 
            this.button数据显示模拟7.Location = new System.Drawing.Point(260, 14);
            this.button数据显示模拟7.Name = "button数据显示模拟7";
            this.button数据显示模拟7.Size = new System.Drawing.Size(69, 23);
            this.button数据显示模拟7.TabIndex = 5;
            this.button数据显示模拟7.Text = "清空显示";
            this.button数据显示模拟7.UseVisualStyleBackColor = true;
            this.button数据显示模拟7.Click += new System.EventHandler(this.button数据显示模拟7_Click);
            // 
            // button数据显示模拟5
            // 
            this.button数据显示模拟5.Location = new System.Drawing.Point(6, 99);
            this.button数据显示模拟5.Name = "button数据显示模拟5";
            this.button数据显示模拟5.Size = new System.Drawing.Size(222, 23);
            this.button数据显示模拟5.TabIndex = 4;
            this.button数据显示模拟5.Text = "带文件的波形显示方式";
            this.button数据显示模拟5.UseVisualStyleBackColor = true;
            this.button数据显示模拟5.Click += new System.EventHandler(this.button数据显示模拟5_Click);
            // 
            // button数据显示模拟4
            // 
            this.button数据显示模拟4.Location = new System.Drawing.Point(234, 70);
            this.button数据显示模拟4.Name = "button数据显示模拟4";
            this.button数据显示模拟4.Size = new System.Drawing.Size(95, 23);
            this.button数据显示模拟4.TabIndex = 3;
            this.button数据显示模拟4.Text = "停止采样模拟";
            this.button数据显示模拟4.UseVisualStyleBackColor = true;
            this.button数据显示模拟4.Click += new System.EventHandler(this.button数据显示模拟4_Click);
            // 
            // button数据显示模拟3
            // 
            this.button数据显示模拟3.Location = new System.Drawing.Point(6, 70);
            this.button数据显示模拟3.Name = "button数据显示模拟3";
            this.button数据显示模拟3.Size = new System.Drawing.Size(222, 23);
            this.button数据显示模拟3.TabIndex = 2;
            this.button数据显示模拟3.Text = "模拟串口采样[周期k]";
            this.button数据显示模拟3.UseVisualStyleBackColor = true;
            this.button数据显示模拟3.Click += new System.EventHandler(this.button数据显示模拟3_Click);
            // 
            // button数据显示模拟2
            // 
            this.button数据显示模拟2.Location = new System.Drawing.Point(166, 41);
            this.button数据显示模拟2.Name = "button数据显示模拟2";
            this.button数据显示模拟2.Size = new System.Drawing.Size(163, 23);
            this.button数据显示模拟2.TabIndex = 1;
            this.button数据显示模拟2.Text = "画三条数据[点|线|矩形条]";
            this.button数据显示模拟2.UseVisualStyleBackColor = true;
            this.button数据显示模拟2.Click += new System.EventHandler(this.button数据显示模拟2_Click);
            // 
            // button数据显示模拟1
            // 
            this.button数据显示模拟1.Location = new System.Drawing.Point(6, 41);
            this.button数据显示模拟1.Name = "button数据显示模拟1";
            this.button数据显示模拟1.Size = new System.Drawing.Size(154, 23);
            this.button数据显示模拟1.TabIndex = 0;
            this.button数据显示模拟1.Text = "-300~num画四条数据";
            this.button数据显示模拟1.UseVisualStyleBackColor = true;
            this.button数据显示模拟1.Click += new System.EventHandler(this.button数据显示模拟1_Click);
            // 
            // groupBox基本属性
            // 
            this.groupBox基本属性.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox基本属性.Controls.Add(this.buttonY轴名称);
            this.groupBox基本属性.Controls.Add(this.buttonX轴名称);
            this.groupBox基本属性.Controls.Add(this.button标题);
            this.groupBox基本属性.Controls.Add(this.label3);
            this.groupBox基本属性.Controls.Add(this.label2);
            this.groupBox基本属性.Controls.Add(this.label1);
            this.groupBox基本属性.Controls.Add(this.textBoxY轴名称);
            this.groupBox基本属性.Controls.Add(this.textBoxX轴名称);
            this.groupBox基本属性.Controls.Add(this.textBox标题);
            this.groupBox基本属性.ForeColor = System.Drawing.Color.Black;
            this.groupBox基本属性.Location = new System.Drawing.Point(361, 3);
            this.groupBox基本属性.Name = "groupBox基本属性";
            this.groupBox基本属性.Size = new System.Drawing.Size(207, 128);
            this.groupBox基本属性.TabIndex = 0;
            this.groupBox基本属性.TabStop = false;
            this.groupBox基本属性.Text = "基本属性";
            // 
            // buttonY轴名称
            // 
            this.buttonY轴名称.Location = new System.Drawing.Point(159, 80);
            this.buttonY轴名称.Name = "buttonY轴名称";
            this.buttonY轴名称.Size = new System.Drawing.Size(42, 23);
            this.buttonY轴名称.TabIndex = 57;
            this.buttonY轴名称.TabStop = false;
            this.buttonY轴名称.Text = "确定";
            this.buttonY轴名称.UseVisualStyleBackColor = true;
            this.buttonY轴名称.Click += new System.EventHandler(this.buttonY轴名称_Click);
            // 
            // buttonX轴名称
            // 
            this.buttonX轴名称.Location = new System.Drawing.Point(159, 51);
            this.buttonX轴名称.Name = "buttonX轴名称";
            this.buttonX轴名称.Size = new System.Drawing.Size(42, 23);
            this.buttonX轴名称.TabIndex = 56;
            this.buttonX轴名称.TabStop = false;
            this.buttonX轴名称.Text = "确定";
            this.buttonX轴名称.UseVisualStyleBackColor = true;
            this.buttonX轴名称.Click += new System.EventHandler(this.buttonX轴名称_Click);
            // 
            // button标题
            // 
            this.button标题.Location = new System.Drawing.Point(159, 22);
            this.button标题.Name = "button标题";
            this.button标题.Size = new System.Drawing.Size(42, 23);
            this.button标题.TabIndex = 55;
            this.button标题.TabStop = false;
            this.button标题.Text = "确定";
            this.button标题.UseVisualStyleBackColor = true;
            this.button标题.Click += new System.EventHandler(this.button标题_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(6, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "Y轴名称";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(6, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "X轴名称";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(6, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "标题";
            // 
            // textBoxY轴名称
            // 
            this.textBoxY轴名称.BackColor = System.Drawing.Color.White;
            this.textBoxY轴名称.ForeColor = System.Drawing.Color.Black;
            this.textBoxY轴名称.Location = new System.Drawing.Point(56, 82);
            this.textBoxY轴名称.Name = "textBoxY轴名称";
            this.textBoxY轴名称.Size = new System.Drawing.Size(97, 21);
            this.textBoxY轴名称.TabIndex = 3;
            this.textBoxY轴名称.TabStop = false;
            this.textBoxY轴名称.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxY轴名称_KeyDown);
            // 
            // textBoxX轴名称
            // 
            this.textBoxX轴名称.BackColor = System.Drawing.Color.White;
            this.textBoxX轴名称.ForeColor = System.Drawing.Color.Black;
            this.textBoxX轴名称.Location = new System.Drawing.Point(56, 53);
            this.textBoxX轴名称.Name = "textBoxX轴名称";
            this.textBoxX轴名称.Size = new System.Drawing.Size(97, 21);
            this.textBoxX轴名称.TabIndex = 2;
            this.textBoxX轴名称.TabStop = false;
            this.textBoxX轴名称.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxX轴名称_KeyDown);
            // 
            // textBox标题
            // 
            this.textBox标题.BackColor = System.Drawing.Color.White;
            this.textBox标题.ForeColor = System.Drawing.Color.Black;
            this.textBox标题.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.textBox标题.Location = new System.Drawing.Point(56, 22);
            this.textBox标题.Name = "textBox标题";
            this.textBox标题.Size = new System.Drawing.Size(97, 21);
            this.textBox标题.TabIndex = 1;
            this.textBox标题.TabStop = false;
            this.textBox标题.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox标题_KeyDown);
            // 
            // button参考样式2
            // 
            this.button参考样式2.Location = new System.Drawing.Point(141, 536);
            this.button参考样式2.Name = "button参考样式2";
            this.button参考样式2.Size = new System.Drawing.Size(51, 23);
            this.button参考样式2.TabIndex = 56;
            this.button参考样式2.TabStop = false;
            this.button参考样式2.Text = "样式2";
            this.button参考样式2.UseVisualStyleBackColor = true;
            this.button参考样式2.Click += new System.EventHandler(this.button参考样式2_Click);
            // 
            // groupBox外观样式
            // 
            this.groupBox外观样式.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox外观样式.Controls.Add(this.button网络线的透明度);
            this.groupBox外观样式.Controls.Add(this.button标题位置);
            this.groupBox外观样式.Controls.Add(this.button标题字体大小);
            this.groupBox外观样式.Controls.Add(this.textBox网络线的透明度);
            this.groupBox外观样式.Controls.Add(this.label27);
            this.groupBox外观样式.Controls.Add(this.label26);
            this.groupBox外观样式.Controls.Add(this.label25);
            this.groupBox外观样式.Controls.Add(this.label24);
            this.groupBox外观样式.Controls.Add(this.label23);
            this.groupBox外观样式.Controls.Add(this.button坐标显示框字体颜色);
            this.groupBox外观样式.Controls.Add(this.button坐标显示框背景颜色);
            this.groupBox外观样式.Controls.Add(this.button标签说明框背景颜色);
            this.groupBox外观样式.Controls.Add(this.button标签说明框文字颜色);
            this.groupBox外观样式.Controls.Add(this.button工具栏按钮前景未选中颜色);
            this.groupBox外观样式.Controls.Add(this.button工具栏按钮前景选中颜色);
            this.groupBox外观样式.Controls.Add(this.textBox标题字体大小);
            this.groupBox外观样式.Controls.Add(this.label8);
            this.groupBox外观样式.Controls.Add(this.button波形显示区域背景色);
            this.groupBox外观样式.Controls.Add(this.button工具栏按钮背景色);
            this.groupBox外观样式.Controls.Add(this.button工具栏背景色);
            this.groupBox外观样式.Controls.Add(this.button网络线的颜色);
            this.groupBox外观样式.Controls.Add(this.button坐标标题颜色);
            this.groupBox外观样式.Controls.Add(this.button坐标值颜色);
            this.groupBox外观样式.Controls.Add(this.button坐标线颜色);
            this.groupBox外观样式.Controls.Add(this.button背景色渐进起始颜色);
            this.groupBox外观样式.Controls.Add(this.button背景色渐进终止颜色);
            this.groupBox外观样式.Controls.Add(this.button标题描边颜色);
            this.groupBox外观样式.Controls.Add(this.button标题颜色);
            this.groupBox外观样式.Controls.Add(this.textBox标题位置);
            this.groupBox外观样式.Controls.Add(this.label9);
            this.groupBox外观样式.Controls.Add(this.label22);
            this.groupBox外观样式.Controls.Add(this.label10);
            this.groupBox外观样式.Controls.Add(this.label21);
            this.groupBox外观样式.Controls.Add(this.label11);
            this.groupBox外观样式.Controls.Add(this.label20);
            this.groupBox外观样式.Controls.Add(this.label12);
            this.groupBox外观样式.Controls.Add(this.label19);
            this.groupBox外观样式.Controls.Add(this.label13);
            this.groupBox外观样式.Controls.Add(this.label18);
            this.groupBox外观样式.Controls.Add(this.label14);
            this.groupBox外观样式.Controls.Add(this.label17);
            this.groupBox外观样式.Controls.Add(this.label15);
            this.groupBox外观样式.Controls.Add(this.label16);
            this.groupBox外观样式.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox外观样式.ForeColor = System.Drawing.Color.Black;
            this.groupBox外观样式.Location = new System.Drawing.Point(5, 5);
            this.groupBox外观样式.Name = "groupBox外观样式";
            this.groupBox外观样式.Size = new System.Drawing.Size(200, 530);
            this.groupBox外观样式.TabIndex = 25;
            this.groupBox外观样式.TabStop = false;
            this.groupBox外观样式.Text = "外观样式";
            // 
            // button网络线的透明度
            // 
            this.button网络线的透明度.Location = new System.Drawing.Point(151, 236);
            this.button网络线的透明度.Name = "button网络线的透明度";
            this.button网络线的透明度.Size = new System.Drawing.Size(42, 23);
            this.button网络线的透明度.TabIndex = 53;
            this.button网络线的透明度.TabStop = false;
            this.button网络线的透明度.Text = "确定";
            this.button网络线的透明度.UseVisualStyleBackColor = true;
            this.button网络线的透明度.Click += new System.EventHandler(this.button网络线的透明度_Click);
            // 
            // button标题位置
            // 
            this.button标题位置.Location = new System.Drawing.Point(151, 42);
            this.button标题位置.Name = "button标题位置";
            this.button标题位置.Size = new System.Drawing.Size(42, 23);
            this.button标题位置.TabIndex = 52;
            this.button标题位置.TabStop = false;
            this.button标题位置.Text = "确定";
            this.button标题位置.UseVisualStyleBackColor = true;
            this.button标题位置.Click += new System.EventHandler(this.button标题位置_Click);
            // 
            // button标题字体大小
            // 
            this.button标题字体大小.Location = new System.Drawing.Point(151, 17);
            this.button标题字体大小.Name = "button标题字体大小";
            this.button标题字体大小.Size = new System.Drawing.Size(42, 23);
            this.button标题字体大小.TabIndex = 51;
            this.button标题字体大小.TabStop = false;
            this.button标题字体大小.Text = "确定";
            this.button标题字体大小.UseVisualStyleBackColor = true;
            this.button标题字体大小.Click += new System.EventHandler(this.button标题字体大小_Click);
            // 
            // textBox网络线的透明度
            // 
            this.textBox网络线的透明度.BackColor = System.Drawing.Color.White;
            this.textBox网络线的透明度.ForeColor = System.Drawing.Color.Black;
            this.textBox网络线的透明度.Location = new System.Drawing.Point(101, 238);
            this.textBox网络线的透明度.Name = "textBox网络线的透明度";
            this.textBox网络线的透明度.Size = new System.Drawing.Size(32, 21);
            this.textBox网络线的透明度.TabIndex = 50;
            this.textBox网络线的透明度.TabStop = false;
            this.textBox网络线的透明度.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox网络线的透明度_KeyDown);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Location = new System.Drawing.Point(6, 484);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(113, 12);
            this.label27.TabIndex = 27;
            this.label27.Text = "坐标显示框字体颜色";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Location = new System.Drawing.Point(6, 460);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(113, 12);
            this.label26.TabIndex = 26;
            this.label26.Text = "坐标显示框背景颜色";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Location = new System.Drawing.Point(6, 436);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(113, 12);
            this.label25.TabIndex = 25;
            this.label25.Text = "标签说明框文字颜色";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Location = new System.Drawing.Point(6, 412);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(113, 12);
            this.label24.TabIndex = 24;
            this.label24.Text = "标签说明框背景颜色";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Location = new System.Drawing.Point(6, 388);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(149, 12);
            this.label23.TabIndex = 23;
            this.label23.Text = "工具栏按钮前景未选中颜色";
            // 
            // button坐标显示框字体颜色
            // 
            this.button坐标显示框字体颜色.BackColor = System.Drawing.Color.White;
            this.button坐标显示框字体颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button坐标显示框字体颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button坐标显示框字体颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button坐标显示框字体颜色.Location = new System.Drawing.Point(161, 480);
            this.button坐标显示框字体颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button坐标显示框字体颜色.Name = "button坐标显示框字体颜色";
            this.button坐标显示框字体颜色.Size = new System.Drawing.Size(20, 20);
            this.button坐标显示框字体颜色.TabIndex = 45;
            this.button坐标显示框字体颜色.TabStop = false;
            this.button坐标显示框字体颜色.UseVisualStyleBackColor = false;
            this.button坐标显示框字体颜色.Click += new System.EventHandler(this.button放大选取框按钮背景颜色_Click);
            // 
            // button坐标显示框背景颜色
            // 
            this.button坐标显示框背景颜色.BackColor = System.Drawing.Color.White;
            this.button坐标显示框背景颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button坐标显示框背景颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button坐标显示框背景颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button坐标显示框背景颜色.Location = new System.Drawing.Point(161, 456);
            this.button坐标显示框背景颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button坐标显示框背景颜色.Name = "button坐标显示框背景颜色";
            this.button坐标显示框背景颜色.Size = new System.Drawing.Size(20, 20);
            this.button坐标显示框背景颜色.TabIndex = 44;
            this.button坐标显示框背景颜色.TabStop = false;
            this.button坐标显示框背景颜色.UseVisualStyleBackColor = false;
            this.button坐标显示框背景颜色.Click += new System.EventHandler(this.button放大选取框背景颜色_Click);
            // 
            // button标签说明框背景颜色
            // 
            this.button标签说明框背景颜色.BackColor = System.Drawing.Color.White;
            this.button标签说明框背景颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button标签说明框背景颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button标签说明框背景颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button标签说明框背景颜色.Location = new System.Drawing.Point(161, 408);
            this.button标签说明框背景颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button标签说明框背景颜色.Name = "button标签说明框背景颜色";
            this.button标签说明框背景颜色.Size = new System.Drawing.Size(20, 20);
            this.button标签说明框背景颜色.TabIndex = 43;
            this.button标签说明框背景颜色.TabStop = false;
            this.button标签说明框背景颜色.UseVisualStyleBackColor = false;
            this.button标签说明框背景颜色.Click += new System.EventHandler(this.button标签说明框背景颜色_Click);
            // 
            // button标签说明框文字颜色
            // 
            this.button标签说明框文字颜色.BackColor = System.Drawing.Color.White;
            this.button标签说明框文字颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button标签说明框文字颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button标签说明框文字颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button标签说明框文字颜色.Location = new System.Drawing.Point(161, 432);
            this.button标签说明框文字颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button标签说明框文字颜色.Name = "button标签说明框文字颜色";
            this.button标签说明框文字颜色.Size = new System.Drawing.Size(20, 20);
            this.button标签说明框文字颜色.TabIndex = 42;
            this.button标签说明框文字颜色.TabStop = false;
            this.button标签说明框文字颜色.UseVisualStyleBackColor = false;
            this.button标签说明框文字颜色.Click += new System.EventHandler(this.button标签说明框文字颜色_Click);
            // 
            // button工具栏按钮前景未选中颜色
            // 
            this.button工具栏按钮前景未选中颜色.BackColor = System.Drawing.Color.White;
            this.button工具栏按钮前景未选中颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button工具栏按钮前景未选中颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button工具栏按钮前景未选中颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button工具栏按钮前景未选中颜色.Location = new System.Drawing.Point(161, 384);
            this.button工具栏按钮前景未选中颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button工具栏按钮前景未选中颜色.Name = "button工具栏按钮前景未选中颜色";
            this.button工具栏按钮前景未选中颜色.Size = new System.Drawing.Size(20, 20);
            this.button工具栏按钮前景未选中颜色.TabIndex = 41;
            this.button工具栏按钮前景未选中颜色.TabStop = false;
            this.button工具栏按钮前景未选中颜色.UseVisualStyleBackColor = false;
            this.button工具栏按钮前景未选中颜色.Click += new System.EventHandler(this.button工具栏按钮前景未选中颜色_Click);
            // 
            // button工具栏按钮前景选中颜色
            // 
            this.button工具栏按钮前景选中颜色.BackColor = System.Drawing.Color.White;
            this.button工具栏按钮前景选中颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button工具栏按钮前景选中颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button工具栏按钮前景选中颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button工具栏按钮前景选中颜色.Location = new System.Drawing.Point(161, 360);
            this.button工具栏按钮前景选中颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button工具栏按钮前景选中颜色.Name = "button工具栏按钮前景选中颜色";
            this.button工具栏按钮前景选中颜色.Size = new System.Drawing.Size(20, 20);
            this.button工具栏按钮前景选中颜色.TabIndex = 40;
            this.button工具栏按钮前景选中颜色.TabStop = false;
            this.button工具栏按钮前景选中颜色.UseVisualStyleBackColor = false;
            this.button工具栏按钮前景选中颜色.Click += new System.EventHandler(this.button工具栏按钮前景选中颜色_Click);
            // 
            // textBox标题字体大小
            // 
            this.textBox标题字体大小.BackColor = System.Drawing.Color.White;
            this.textBox标题字体大小.ForeColor = System.Drawing.Color.Black;
            this.textBox标题字体大小.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textBox标题字体大小.Location = new System.Drawing.Point(88, 19);
            this.textBox标题字体大小.Margin = new System.Windows.Forms.Padding(2);
            this.textBox标题字体大小.Name = "textBox标题字体大小";
            this.textBox标题字体大小.Size = new System.Drawing.Size(45, 21);
            this.textBox标题字体大小.TabIndex = 24;
            this.textBox标题字体大小.TabStop = false;
            this.textBox标题字体大小.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox标题字体大小_KeyDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Location = new System.Drawing.Point(6, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 12);
            this.label8.TabIndex = 9;
            this.label8.Text = "标题字体大小";
            // 
            // button波形显示区域背景色
            // 
            this.button波形显示区域背景色.BackColor = System.Drawing.Color.White;
            this.button波形显示区域背景色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button波形显示区域背景色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button波形显示区域背景色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button波形显示区域背景色.Location = new System.Drawing.Point(161, 288);
            this.button波形显示区域背景色.Margin = new System.Windows.Forms.Padding(2);
            this.button波形显示区域背景色.Name = "button波形显示区域背景色";
            this.button波形显示区域背景色.Size = new System.Drawing.Size(20, 20);
            this.button波形显示区域背景色.TabIndex = 39;
            this.button波形显示区域背景色.TabStop = false;
            this.button波形显示区域背景色.UseVisualStyleBackColor = false;
            this.button波形显示区域背景色.Click += new System.EventHandler(this.button波形显示区域背景色_Click);
            // 
            // button工具栏按钮背景色
            // 
            this.button工具栏按钮背景色.BackColor = System.Drawing.Color.White;
            this.button工具栏按钮背景色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button工具栏按钮背景色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button工具栏按钮背景色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button工具栏按钮背景色.Location = new System.Drawing.Point(161, 336);
            this.button工具栏按钮背景色.Margin = new System.Windows.Forms.Padding(2);
            this.button工具栏按钮背景色.Name = "button工具栏按钮背景色";
            this.button工具栏按钮背景色.Size = new System.Drawing.Size(20, 20);
            this.button工具栏按钮背景色.TabIndex = 38;
            this.button工具栏按钮背景色.TabStop = false;
            this.button工具栏按钮背景色.UseVisualStyleBackColor = false;
            this.button工具栏按钮背景色.Click += new System.EventHandler(this.button工具栏按钮背景色_Click);
            // 
            // button工具栏背景色
            // 
            this.button工具栏背景色.BackColor = System.Drawing.Color.White;
            this.button工具栏背景色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button工具栏背景色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button工具栏背景色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button工具栏背景色.Location = new System.Drawing.Point(161, 312);
            this.button工具栏背景色.Margin = new System.Windows.Forms.Padding(2);
            this.button工具栏背景色.Name = "button工具栏背景色";
            this.button工具栏背景色.Size = new System.Drawing.Size(20, 20);
            this.button工具栏背景色.TabIndex = 37;
            this.button工具栏背景色.TabStop = false;
            this.button工具栏背景色.UseVisualStyleBackColor = false;
            this.button工具栏背景色.Click += new System.EventHandler(this.button工具栏背景色_Click);
            // 
            // button网络线的颜色
            // 
            this.button网络线的颜色.BackColor = System.Drawing.Color.White;
            this.button网络线的颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button网络线的颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button网络线的颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button网络线的颜色.Location = new System.Drawing.Point(161, 264);
            this.button网络线的颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button网络线的颜色.Name = "button网络线的颜色";
            this.button网络线的颜色.Size = new System.Drawing.Size(20, 20);
            this.button网络线的颜色.TabIndex = 36;
            this.button网络线的颜色.TabStop = false;
            this.button网络线的颜色.UseVisualStyleBackColor = false;
            this.button网络线的颜色.Click += new System.EventHandler(this.button网络线的颜色_Click);
            // 
            // button坐标标题颜色
            // 
            this.button坐标标题颜色.BackColor = System.Drawing.Color.White;
            this.button坐标标题颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button坐标标题颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button坐标标题颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button坐标标题颜色.Location = new System.Drawing.Point(161, 213);
            this.button坐标标题颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button坐标标题颜色.Name = "button坐标标题颜色";
            this.button坐标标题颜色.Size = new System.Drawing.Size(20, 20);
            this.button坐标标题颜色.TabIndex = 35;
            this.button坐标标题颜色.TabStop = false;
            this.button坐标标题颜色.UseVisualStyleBackColor = false;
            this.button坐标标题颜色.Click += new System.EventHandler(this.button坐标标题颜色_Click);
            // 
            // button坐标值颜色
            // 
            this.button坐标值颜色.BackColor = System.Drawing.Color.White;
            this.button坐标值颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button坐标值颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button坐标值颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button坐标值颜色.Location = new System.Drawing.Point(161, 189);
            this.button坐标值颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button坐标值颜色.Name = "button坐标值颜色";
            this.button坐标值颜色.Size = new System.Drawing.Size(20, 20);
            this.button坐标值颜色.TabIndex = 34;
            this.button坐标值颜色.TabStop = false;
            this.button坐标值颜色.UseVisualStyleBackColor = false;
            this.button坐标值颜色.Click += new System.EventHandler(this.button坐标值颜色_Click);
            // 
            // button坐标线颜色
            // 
            this.button坐标线颜色.BackColor = System.Drawing.Color.White;
            this.button坐标线颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button坐标线颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button坐标线颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button坐标线颜色.Location = new System.Drawing.Point(161, 165);
            this.button坐标线颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button坐标线颜色.Name = "button坐标线颜色";
            this.button坐标线颜色.Size = new System.Drawing.Size(20, 20);
            this.button坐标线颜色.TabIndex = 33;
            this.button坐标线颜色.TabStop = false;
            this.button坐标线颜色.UseVisualStyleBackColor = false;
            this.button坐标线颜色.Click += new System.EventHandler(this.button坐标线颜色_Click);
            // 
            // button背景色渐进起始颜色
            // 
            this.button背景色渐进起始颜色.BackColor = System.Drawing.Color.White;
            this.button背景色渐进起始颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button背景色渐进起始颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button背景色渐进起始颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button背景色渐进起始颜色.Location = new System.Drawing.Point(161, 117);
            this.button背景色渐进起始颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button背景色渐进起始颜色.Name = "button背景色渐进起始颜色";
            this.button背景色渐进起始颜色.Size = new System.Drawing.Size(20, 20);
            this.button背景色渐进起始颜色.TabIndex = 32;
            this.button背景色渐进起始颜色.TabStop = false;
            this.button背景色渐进起始颜色.UseVisualStyleBackColor = false;
            this.button背景色渐进起始颜色.Click += new System.EventHandler(this.button背景色渐进起始颜色_Click);
            // 
            // button背景色渐进终止颜色
            // 
            this.button背景色渐进终止颜色.BackColor = System.Drawing.Color.White;
            this.button背景色渐进终止颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button背景色渐进终止颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button背景色渐进终止颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button背景色渐进终止颜色.Location = new System.Drawing.Point(161, 141);
            this.button背景色渐进终止颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button背景色渐进终止颜色.Name = "button背景色渐进终止颜色";
            this.button背景色渐进终止颜色.Size = new System.Drawing.Size(20, 20);
            this.button背景色渐进终止颜色.TabIndex = 31;
            this.button背景色渐进终止颜色.TabStop = false;
            this.button背景色渐进终止颜色.UseVisualStyleBackColor = false;
            this.button背景色渐进终止颜色.Click += new System.EventHandler(this.button背景色渐进终止颜色_Click);
            // 
            // button标题描边颜色
            // 
            this.button标题描边颜色.BackColor = System.Drawing.Color.White;
            this.button标题描边颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button标题描边颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button标题描边颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button标题描边颜色.Location = new System.Drawing.Point(161, 93);
            this.button标题描边颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button标题描边颜色.Name = "button标题描边颜色";
            this.button标题描边颜色.Size = new System.Drawing.Size(20, 20);
            this.button标题描边颜色.TabIndex = 30;
            this.button标题描边颜色.TabStop = false;
            this.button标题描边颜色.UseVisualStyleBackColor = false;
            this.button标题描边颜色.Click += new System.EventHandler(this.button标题描边颜色_Click);
            // 
            // button标题颜色
            // 
            this.button标题颜色.BackColor = System.Drawing.Color.White;
            this.button标题颜色.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button标题颜色.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button标题颜色.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button标题颜色.Location = new System.Drawing.Point(161, 69);
            this.button标题颜色.Margin = new System.Windows.Forms.Padding(2);
            this.button标题颜色.Name = "button标题颜色";
            this.button标题颜色.Size = new System.Drawing.Size(20, 20);
            this.button标题颜色.TabIndex = 29;
            this.button标题颜色.TabStop = false;
            this.button标题颜色.UseVisualStyleBackColor = false;
            this.button标题颜色.Click += new System.EventHandler(this.button标题颜色_Click);
            // 
            // textBox标题位置
            // 
            this.textBox标题位置.BackColor = System.Drawing.Color.White;
            this.textBox标题位置.ForeColor = System.Drawing.Color.Black;
            this.textBox标题位置.Location = new System.Drawing.Point(88, 44);
            this.textBox标题位置.Margin = new System.Windows.Forms.Padding(2);
            this.textBox标题位置.Name = "textBox标题位置";
            this.textBox标题位置.Size = new System.Drawing.Size(45, 21);
            this.textBox标题位置.TabIndex = 25;
            this.textBox标题位置.TabStop = false;
            this.textBox标题位置.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox标题位置_KeyDown);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Location = new System.Drawing.Point(6, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 10;
            this.label9.Text = "标题位置";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Location = new System.Drawing.Point(6, 340);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(101, 12);
            this.label22.TabIndex = 23;
            this.label22.Text = "工具栏按钮背景色";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Location = new System.Drawing.Point(6, 73);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 11;
            this.label10.Text = "标题颜色";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Location = new System.Drawing.Point(6, 364);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(137, 12);
            this.label21.TabIndex = 22;
            this.label21.Text = "工具栏按钮前景选中颜色";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Location = new System.Drawing.Point(6, 97);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 12;
            this.label11.Text = "标题描边颜色";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Location = new System.Drawing.Point(6, 316);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 12);
            this.label20.TabIndex = 21;
            this.label20.Text = "工具栏背景色";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Location = new System.Drawing.Point(6, 121);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(113, 12);
            this.label12.TabIndex = 13;
            this.label12.Text = "背景色渐进起始颜色";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Location = new System.Drawing.Point(6, 292);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(113, 12);
            this.label19.TabIndex = 20;
            this.label19.Text = "波形显示区域背景色";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Location = new System.Drawing.Point(6, 145);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 12);
            this.label13.TabIndex = 14;
            this.label13.Text = "背景色渐进终止颜色";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Location = new System.Drawing.Point(6, 268);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 12);
            this.label18.TabIndex = 19;
            this.label18.Text = "网格线的颜色";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Location = new System.Drawing.Point(6, 169);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 15;
            this.label14.Text = "坐标线颜色";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Location = new System.Drawing.Point(6, 241);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(89, 12);
            this.label17.TabIndex = 18;
            this.label17.Text = "网格线的透明度";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Location = new System.Drawing.Point(6, 193);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 16;
            this.label15.Text = "坐标值颜色";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Location = new System.Drawing.Point(6, 217);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 12);
            this.label16.TabIndex = 17;
            this.label16.Text = "坐标标题颜色";
            // 
            // button默认样式
            // 
            this.button默认样式.Location = new System.Drawing.Point(7, 536);
            this.button默认样式.Name = "button默认样式";
            this.button默认样式.Size = new System.Drawing.Size(71, 23);
            this.button默认样式.TabIndex = 54;
            this.button默认样式.TabStop = false;
            this.button默认样式.Text = "默认样式";
            this.button默认样式.UseVisualStyleBackColor = true;
            this.button默认样式.Click += new System.EventHandler(this.button默认样式_Click);
            // 
            // button参考样式1
            // 
            this.button参考样式1.Location = new System.Drawing.Point(84, 536);
            this.button参考样式1.Name = "button参考样式1";
            this.button参考样式1.Size = new System.Drawing.Size(51, 23);
            this.button参考样式1.TabIndex = 55;
            this.button参考样式1.TabStop = false;
            this.button参考样式1.Text = "样式1";
            this.button参考样式1.UseVisualStyleBackColor = true;
            this.button参考样式1.Click += new System.EventHandler(this.button参考样式1_Click);
            // 
            // timerDraw
            // 
            this.timerDraw.Interval = 200;
            this.timerDraw.Tick += new System.EventHandler(this.timerDraw_Tick);
            // 
            // timerRandom
            // 
            this.timerRandom.Tick += new System.EventHandler(this.timerRandom_Tick);
            // 
            // FormTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(792, 573);
            this.Controls.Add(this.splitContainer1);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "FormTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "波形显示控件测试";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            this.groupBox数据显示模拟.ResumeLayout(false);
            this.groupBox数据显示模拟.PerformLayout();
            this.groupBox基本属性.ResumeLayout(false);
            this.groupBox基本属性.PerformLayout();
            this.groupBox外观样式.ResumeLayout(false);
            this.groupBox外观样式.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Pengpai.UI.ZGraph zGraphTest;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.GroupBox groupBox基本属性;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxY轴名称;  
        private System.Windows.Forms.TextBox textBoxX轴名称;
        private System.Windows.Forms.TextBox textBox标题;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox外观样式;
        private System.Windows.Forms.Button button标题描边颜色;
        private System.Windows.Forms.Button button标题颜色;
        private System.Windows.Forms.TextBox textBox标题位置;
        private System.Windows.Forms.TextBox textBox标题字体大小;
        private System.Windows.Forms.Button button坐标值颜色;
        private System.Windows.Forms.Button button坐标线颜色;
        private System.Windows.Forms.Button button背景色渐进起始颜色;
        private System.Windows.Forms.Button button背景色渐进终止颜色;
        private System.Windows.Forms.TextBox textBox网络线的透明度;
        private System.Windows.Forms.Button button坐标显示框字体颜色;
        private System.Windows.Forms.Button button坐标显示框背景颜色;
        private System.Windows.Forms.Button button标签说明框背景颜色;
        private System.Windows.Forms.Button button标签说明框文字颜色;
        private System.Windows.Forms.Button button工具栏按钮前景未选中颜色;
        private System.Windows.Forms.Button button工具栏按钮前景选中颜色;
        private System.Windows.Forms.Button button波形显示区域背景色;
        private System.Windows.Forms.Button button工具栏按钮背景色;
        private System.Windows.Forms.Button button工具栏背景色;
        private System.Windows.Forms.Button button网络线的颜色;
        private System.Windows.Forms.Button button坐标标题颜色;
        private System.Windows.Forms.Button button标题位置;
        private System.Windows.Forms.Button button标题字体大小;
        private System.Windows.Forms.Button button网络线的透明度;
        private System.Windows.Forms.Button buttonY轴名称;
        private System.Windows.Forms.Button buttonX轴名称;
        private System.Windows.Forms.Button button标题;
        private System.Windows.Forms.Button button参考样式2;
        private System.Windows.Forms.Button button参考样式1;
        private System.Windows.Forms.Button button默认样式;
        private System.Windows.Forms.GroupBox groupBox数据显示模拟;
        private System.Windows.Forms.Button button数据显示模拟7;
        private System.Windows.Forms.Button button数据显示模拟5;
        private System.Windows.Forms.Button button数据显示模拟4;
        private System.Windows.Forms.Button button数据显示模拟3;
        private System.Windows.Forms.Button button数据显示模拟2;
        private System.Windows.Forms.Button button数据显示模拟1;
        private System.Windows.Forms.TextBox textBox数值;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox附加参数;
        private System.Windows.Forms.Timer timerDraw;
        private System.Windows.Forms.Button button数据显示模拟6;
        private System.Windows.Forms.Timer timerRandom;
    }
}

